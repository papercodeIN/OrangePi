#include <wiringPi.h>
unsigned int  digitalRead8        (int pin) { return 0;}
void digitalWrite8       (int pin, int value) {}